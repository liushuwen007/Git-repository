package web;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.AdminDao;
import dao.CostDao;
import entity.Admin;
import entity.Cost;
import util.DBUtil;
import util.ImageUtil;

public class MainServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String path = req.getServletPath();//获取请求路径
		//根据规范作出判断及处理
		if("/findCost.do".equals(path)) {
			findCost(req,res);
		} else if("/toAddCost.do".equals(path)){
			toAddCost(req,res);
		} else if("/addCost.do".equals(path)) {
			addCost(req,res);
		} else if("/toUpdateCost.do".equals(path)) {
			toUpdateCost(req,res);
		} else if("/toLogin.do".equals(path)) {
			toLogin(req,res);
		} else if("/toIndex.do".equals(path)) {
			toIndex(req,res);
		} else if("/login.do".equals(path)) {
			login(req,res);
		} else if("/createImg.do".equals(path)) {
			createImg(req,res);
		} else if("/logout.do".equals(path)) {
			logout(req,res);
		} else if("/updateCost.do".equals(path)) {
			updateCost(req, res);
		} else if("/deleteCost.do".equals(path)) {
			deleteCost(req,res);
		} else if("/findCostDetail.do".equals(path)) {
			findCostDetail(req,res);
		} else if("/updateCostStatus.do".equals(path)) {
			updateCostStatus(req, res);
		} else {
			throw new RuntimeException("查无此页");
		}
	}
	
		//当前第几页，默认第一页
		int curPage=1;      
		//每页显示多少条数据，默认显示10条数据
		int rowsPrePage=10;      
		
	protected void findCost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{
		int MaxRowCount=getRowsCount();//获取总记录数 49
		int tempPage1=MaxRowCount%rowsPrePage;
		int tempPage2=MaxRowCount/rowsPrePage;
		int MaxPage=(tempPage1==0)?tempPage2:(tempPage2+1);//总共多少页 5
		String cur=req.getParameter("curPage");//获取页面传过来的当前页数
		if(cur!=null && !"".equals(cur)){
			curPage=Integer.parseInt(cur);
		}
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			//由于curPage需要从request中获取，所以st.setInt()不能写在CostDao里面。
			PreparedStatement st=con.prepareStatement("select * from (select c.*,rownum rn from (select * from cost order by cost_id) c)where rn between ? and ?");
			st.setInt(1,(curPage-1)*rowsPrePage+1 );
			st.setInt(2,curPage*rowsPrePage );
			ResultSet rs=st.executeQuery();
			List<Cost> list=new ArrayList<Cost>();
			while(rs.next()){
				Cost c=new Cost();
				c.setCostId(rs.getInt("cost_id"));
				c.setName(rs.getString("name"));
				c.setBaseDuration(rs.getInt("base_duration"));
				c.setBaseCost(rs.getDouble("base_cost"));
				c.setUnitCost(rs.getDouble("unit_cost"));
				c.setStatus(rs.getString("status"));
				c.setDescr(rs.getString("descr"));
				c.setCreatime(rs.getTimestamp("creatime"));
				c.setStartime(rs.getTimestamp("startime"));
				c.setCostType(rs.getString("cost_type"));
				list.add(c);
			}
			req.setAttribute("costs", list);
			req.setAttribute("countPage", MaxPage);
			req.setAttribute("cur", curPage);
			req.getRequestDispatcher("WEB-INF/cost/find.jsp").forward(req, res);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(con);
		}
	}
			
	//获取表里面的总记录数
	public  static int getRowsCount() {
		int count=0;
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			Statement st=con.createStatement();
			String sql=" select count(*) from cost ";
			ResultSet rs=st.executeQuery(sql);
			if(rs.next()){
				count=rs.getInt(1);//取出第一行数据
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("获取列表失败");
		} finally {
			DBUtil.close(con);
		}
		return count;
	}
	
	protected void updateCostStatus(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{
			String costId = req.getParameter("id");
			CostDao dao = new CostDao();
			dao.updateCostStatus(new Integer(costId));
			//重定向到查询
			res.sendRedirect("findCost.do");
	}
	
	protected void findCostDetail(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{
			String id = req.getParameter("id");
			//查询要修改的资费
			CostDao dao = new CostDao();
			Cost cost = dao.findById(new Integer(id));
			//将其转发到修改页面
			req.setAttribute("cost", cost);
			req.getRequestDispatcher("WEB-INF/cost/detail.jsp").forward(req, res);
	}
	
	protected void deleteCost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{
			String id = req.getParameter("id");
			CostDao dao = new CostDao();
			dao.delete(new Integer(id));
			res.sendRedirect("findCost.do");
	}
	
	protected void updateCost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException{
			req.setCharacterEncoding("utf-8");
			//参数的名字可以任意命名，为了便于记忆通常和实体属性同名。
			String costId = req.getParameter("costId");
			String name = req.getParameter("name");
			String baseDuration = req.getParameter("baseDuration");
			String baseCost =req.getParameter("baseCost");
			String unitCost = req.getParameter("unitCost");
			String descr = req.getParameter("descr");
			String costType = req.getParameter("costType");
			//修改这些数据
			Cost c = new Cost();
			c.setCostId(new Integer(costId));
			c.setName(name);
			c.setDescr(descr);
			c.setCostType(costType);
			if(baseDuration != null&& !baseDuration.equals("")) {
				c.setBaseDuration(new Integer(baseDuration));
			}
			if(baseCost != null&& !baseCost.equals("")) {
				c.setBaseCost(new Double(baseCost));
			}
			if(unitCost != null&& !unitCost.equals("")) {
				c.setUnitCost(new Double(unitCost));
			}
			CostDao dao = new CostDao();
			dao.update(c);
			//重定向到查询
			res.sendRedirect("findCost.do");
	}

	protected void logout(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession session = req.getSession();
		session.invalidate();
		res.sendRedirect("toLogin.do");
	}

	//生成验证码
	protected void createImg(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//生成验证码及图片
		Object[] objs = ImageUtil.createImage();
		//将验证码存入session
		String imgcode = (String) objs[0];
		HttpSession session = req.getSession();
		session.setAttribute("imgcode", imgcode);
		//将图片输出给浏览器
		res.setContentType("image/jpeg");
		BufferedImage img = (BufferedImage) objs[1];
		//该输出流由tomcat创建，目标是浏览器
		OutputStream os = res.getOutputStream();
		ImageIO.write(img, "jpeg", os);
		os.close();
	}
	
	//登录验证
	protected void login(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException {
		//获取传入的表单数据
		String adminCode = req.getParameter("adminCode");
		String password = req.getParameter("password");
		String code = req.getParameter("code");
		//检查验证码
		HttpSession session = req.getSession();
		String imgcode = (String)session.getAttribute("imgcode");
		if(code == null|| code.equals("")|| !code.equalsIgnoreCase(imgcode)) {
			req.setAttribute("error", "验证码错误");
			req.getRequestDispatcher("WEB-INF/main/login.jsp").forward(req, res);
			return;
		}
		//验证账号和密码
		AdminDao dao = new AdminDao();
		Admin a = dao.findByCode(adminCode);
		if(a == null) {
			//账号错误，转发到登录页
			req.setAttribute("error", "账号错误");
			req.getRequestDispatcher("WEB-INF/main/login.jsp").forward(req, res);
		} else if(!a.getPassword().equals(password)) {
			//密码错误，转发到登录页
			req.setAttribute("error", "密码错误");
			req.getRequestDispatcher("WEB-INF/main/login.jsp").forward(req, res);
		} else {
			//将账号存入cookie，后续资费查询、
			//增加、修改等页面上要显示它。
			Cookie c = new Cookie("adminCode",adminCode);
			res.addCookie(c);
			//将账号存入session，后续资费查询、
			//增加、修改等页面上要显示它。
			session.setAttribute("adminCode", adminCode);
			//验证通过，重定向到主页
			res.sendRedirect("toIndex.do");
		}
	}
	
	//打开主页
	protected void toIndex(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.getRequestDispatcher("WEB-INF/main/index.jsp").forward(req, res);
	}	

	//打开登录页面
	protected void toLogin(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.getRequestDispatcher("WEB-INF/main/login.jsp").forward(req, res);
	}
	
	//打开修改资费页面
	protected void toUpdateCost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//接收参数
		String id = req.getParameter("id");
		//查询要修改的资费
		CostDao dao = new CostDao();
		Cost cost = dao.findById(new Integer(id));
		//将其转发到修改页面
		req.setAttribute("cost", cost);
		req.getRequestDispatcher("WEB-INF/cost/update.jsp").forward(req, res);
	}
	
	//增加资费
	protected void addCost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		//接收表单提交的数据
		String name = req.getParameter("name");
		String costType = req.getParameter("costType");
		String baseDuration = req.getParameter("baseDuration");
		String baseCost = req.getParameter("baseCost");
		String unitCost = req.getParameter("unitCost");
		String descr = req.getParameter("descr");
		//封装并保存这些数据
		Cost c = new Cost();
		c.setName(name);
		c.setCostType(costType);
		c.setDescr(descr);
		if(baseDuration != null&& !baseDuration.equals("")) {
			c.setBaseDuration(new Integer(baseDuration));
		}
		if(baseCost != null&& !baseCost.equals("")) {
			c.setBaseCost(new Double(baseCost));
		}
		if(unitCost != null&& !unitCost.equals("")) {
			c.setUnitCost(new Double(unitCost));
		}
		CostDao dao = new CostDao();
		dao.save(c);
		//重定向到资费查询
		//当前:/netctoss/addCost.do
		//目标:/netctoss/findCost.do
		res.sendRedirect("findCost.do");
	}
	
	//打开增加资费页面
	protected void toAddCost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//当前:/netctoss/toAddCost.do
		//目标:/netctoss/WEB-INF/cost/add.jsp
		req.getRequestDispatcher("WEB-INF/cost/add.jsp").forward(req, res);
	}
	
	//查询所有的资费
	/*
	protected void findCost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//查询所有的资费
		CostDao dao = new CostDao();
		List<Cost> list = dao.findAll();
		//转发到查询的jsp
		req.setAttribute("costs", list);
		//当前:/netctoss/findCost.do
		//目标:/netctoss/WEB-INF/cost/find.jsp
		req.getRequestDispatcher("WEB-INF/cost/find.jsp").forward(req, res);
	}
	*/
}


